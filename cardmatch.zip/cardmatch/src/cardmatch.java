import javax.swing.*; // Used for creating GUI elements
import javax.swing.Timer;
import java.awt.*; // Used for creating GUI elements
import java.awt.event.*; // Enables us to detect when buttons are pressed
import java.util.*; // Used for various functions

public class cardmatch implements ActionListener
{
    private JButton[][] cardButtons; // Stores each card button
    private final JPanel cardGridPanel; // This is so we can change the JPanel when the buttons are pressed
    JButton resetButton, quitButton; // Used for creating the buttons
    JTextArea guessesMade, matchesMade, winningMessage; // Used for giving the user information
    private int cardsFlipped, guesses = 0, matches = 0, flippedI, flippedJ;
    private Boolean[][] matchedCards; // Stores the cards that have been matched
    cardmatch()
    {
        // Create the JFrame for everything to be contained in
        JFrame frame = new JFrame("Card Matching");
        // This allows the panels to be oriented in the JFrame
        frame.setLayout(new BorderLayout());
        // Create a button to reset the game
        resetButton = new JButton("Reset");
        resetButton.addActionListener(this);
        // Create a button to quit the program
        quitButton = new JButton("Quit");
        quitButton.addActionListener(this);
        // Create an output field for the number of matches made
        matchesMade = new JTextArea("Matches Made: " + matches);
        matchesMade.setEditable(false);
        // Create an output field for the number of guesses made
        guessesMade = new JTextArea("Guesses Made: " + guesses);
        guessesMade.setEditable(false);
        // Create an output field for the winning message
        winningMessage = new JTextArea("You won! To play again, press \"Reset.\" To quit, press \"Quit.\""); // Set the winning message
        winningMessage.setEditable(false);
        // Add the buttons and text areas to the bottom panel
        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.add(guessesMade);
        bottomPanel.add(resetButton);
        bottomPanel.add(quitButton);
        bottomPanel.add(matchesMade);
        // Add the bottom panel to the bottom of the frame
        frame.add(bottomPanel, BorderLayout.SOUTH);
        // Create a new JPanel grid for the cards
        cardGridPanel = new JPanel(new GridLayout(4, 13, 5, 5));
        // Add the card grid panel to the center of the frame
        frame.add(cardGridPanel, BorderLayout.CENTER);
        // Initialize the cardButtons array
        initializeCardButtons();
        // Randomize the cardButtons array
        randomizeCardButtons();
        // Add each button to the panel
        for (int i = 0; i <= 3; i++)
        {
            for (int j = 0; j <= 12; j++)
            {
                cardGridPanel.add(cardButtons[i][j]);
            }
        }
        // Add the panel to the center
        frame.add(cardGridPanel, BorderLayout.CENTER);
        // Set the default close operation to close upon closing the window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Make the frame full screen
        frame.setSize(1920, 1080);
        // Disable the cards so that they cannot be pressed before the game starts
        disableUnmatched();
        // Display the frame
        frame.setVisible(true);
        // Pause for three seconds
        Timer timer = new Timer(3000, e ->
        {
            flipCardsToBack(); // Flip the cards to the back after 3 seconds
            enableUnmatched(); // Enable the cards
        }); // Add a timer
        timer.setRepeats(false); // The timer only iterates once
        timer.start(); // Starts the timer
    }
    private void flipCardsToBack()
    {
        for (int i = 0; i <= 3; i++) // Iterate over the rows
        {
            for (int j = 0; j <= 12; j++) // Iterate over the columns
            {
                if (!matchedCards[i][j]) // If the card is not a matched card
                {
                    ImageIcon back = new ImageIcon("card_back.png"); // Declare the icon for the back
                    cardButtons[i][j].setIcon(back); // Set the icon to show the back of the card
                }
            }
        }
        cardGridPanel.revalidate(); // Recalculates the layout of the cards
        cardGridPanel.repaint(); // Updates the screen with what is in the panel
    }
    private void enableUnmatched()
    {
        for (int i = 0; i <= 3; i++) // Iterate over the rows
        {
            for (int j = 0; j <= 12; j++) // Iterate over the columns
            {
                if (!matchedCards[i][j]) // If the card is supposed to have an action listener
                {
                    cardButtons[i][j].addActionListener(this); // Add action listener
                }
            }
        }
    }
    private void disableUnmatched()
    {
        for (int i = 0; i <= 3; i++) // Iterate over the rows
        {
            for (int j = 0; j <= 12; j++) // Iterate over the columns
            {
                if (!matchedCards[i][j]) // If the card already doesn't have an action listener
                {
                    cardButtons[i][j].removeActionListener(this); // Remove the action listener
                }
            }
        }
    }
    private void initializeCardButtons ()
    {
        cardGridPanel.remove(winningMessage); // Remove the winning message if it's there
        cardButtons = new JButton[4][13]; // Initialize as a 2-dimensional array
        matchedCards = new Boolean[4][13]; // Initialize the array for matched cards
        String suit = null; // Initialize the suit to null
        for (int i = 0; i <= 3; i++) // Iterate over the rows
        {
            switch (i)
            {
                case 0 -> suit = "clubs"; // The first row is clubs
                case 1 -> suit = "diamonds"; // The second row is diamonds
                case 2 -> suit = "hearts"; // The third row is hearts
                case 3 -> suit = "spades"; // The fourth row is spades
            }
            String value; // Initialize the value
            for (int j = 0; j < 13; j++) // Iterate over the columns
            {
                String temp = suit; // Temporary variable for changing the card style
                switch (j)
                {
                    case 0 -> value = "ace"; // The first column contains aces
                    case 10 -> {value = "jack"; temp += "2";} // The 11th column contains jacks (second style)
                    case 11 -> {value = "queen"; temp += "2";} // The 12th column contains queens (second style)
                    case 12 -> {value = "king"; temp += "2";} // The 13th column contains kings (second style)
                    default -> value = String.valueOf(j + 1); // If none of these cases, then the value is j + 1
                }
                if (Objects.equals(suit, "spades") && value.equals("ace")) // If it's an ace of spades
                {
                    temp = temp + "2"; // Choose second style
                }

                String filename = value + "_of_" + temp + "_icon.png"; // Declare filename
                ImageIcon front = new ImageIcon(filename); // Define an icon for the front of the card
                JButton cardButton = new JButton(front); // Create a JButton with the icon
                cardButton.addActionListener(this); // Add an action listener to the card
                cardButton.putClientProperty("value", value); // Stores the value in the JButton
                cardButton.putClientProperty("filename", filename); // Stores the filename in the JButton
                cardButtons[i][j] = cardButton; // Add the card to the array
                matchedCards[i][j] = false; // Set the matched status to false
            }
        }
    }
    private void randomizeCardButtons()
    {
        ArrayList<JButton> values = new ArrayList<>(); // Creates a new array list
        for (int i = 0; i <= 3; i++) // Iterate over the rows
        {
            values.addAll(Arrays.asList(cardButtons[i]).subList(0, 13)); // Adds the row to the ArrayList
        }
        Collections.shuffle(values); // Shuffles the cards
        for (int i = 0; i <= 3; i++) // Iterate over the rows
        {
            for (int j = 0; j <= 12; j++) // Iterate over the columns
            {
                cardButtons[i][j] = values.get(13 * i + j); // Puts every element into the array
            }
        }
    }
    private void gameWon()
    {
        int unmatched = 0; // Initialize the unmatched variable
        for (int i = 0; i <= 3; i++) // Iterate over rows
        {
            for (int j = 0; j <= 12; j++) // Iterate over columns
            {
                if (!matchedCards[i][j]) // If the card isn't matched
                {
                    unmatched++; // Increment the number of unmatched cards
                }
            }
        }
        if (unmatched == 0) // If all cards are matched
        {
            cardGridPanel.removeAll(); // Remove all cards from the panel
            cardGridPanel.add(winningMessage); // Add the winning message
            cardGridPanel.revalidate(); // Recalculates the layout of the cards
            cardGridPanel.repaint(); // Updates the screen with what is in the panel
        }
    }
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == resetButton) // If the "Reset" button was pressed
        {
            resetButton.setEnabled(false); // Temporarily disable the reset button
            matches = 0; // Reset the matches counter
            matchesMade.setText("Matches Made: " + matches); // Display the matches
            guesses = 0; // Reset the guesses counter
            guessesMade.setText("Guesses Made: " + guesses); // Display the guesses
            cardGridPanel.removeAll(); // Remove all the current elements
            initializeCardButtons(); // Puts the elements of cardButtons back in order
            randomizeCardButtons(); // Randomize the cards
            // Add each button to the panel
            for (int i = 0; i <= 3; i++) // Iterate over rows
            {
                for (int j = 0; j <= 12; j++) // Iterate over columns
                {
                    cardGridPanel.add(cardButtons[i][j]); // Add the button to the panel
                }
            }
            cardGridPanel.revalidate(); // Recalculates the layout of the cards
            cardGridPanel.repaint(); // Updates the screen with what is in the panel
            Timer timer = new Timer(3000, e1 ->
            {
                flipCardsToBack(); // Flip the cards after 3 seconds
                resetButton.setEnabled(true); // Enable the reset button again
            }); // Add a timer
            timer.setRepeats(false); // The timer only iterates once
            timer.start(); // Starts the timer
        }
        else if (e.getSource() == quitButton) // If the "Quit" button is pressed
        {
            System.exit(0); // Quit the program
        }
        else // If a card is pressed
        {
            for (int i = 0; i <= 3; i++) // Iterate over rows
            {
                for (int j = 0; j <= 12; j++) // Iterate over columns
                {
                    if (e.getSource() == cardButtons[i][j]) // If this card was pressed
                    {
                        resetButton.setEnabled(false); // Temporarily disable the reset button
                        String filename = (String) cardButtons[i][j].getClientProperty("filename"); // Get the filename of the front of the card
                        ImageIcon front = new ImageIcon(filename); // Create an icon of the front
                        cardButtons[i][j].setIcon(front); // Set the button's icon to the file
                        cardsFlipped++; // Increment the cardsFlipped
                        cardGridPanel.revalidate(); // Recalculates the layout of the cards
                        cardGridPanel.repaint(); // Updates the screen with what is in the panel
                        cardButtons[i][j].removeActionListener(this); // Make the card un-clickable
                        if (cardsFlipped == 1) // If this was the first card flipped
                        {
                            flippedI = i; // Store the row
                            flippedJ = j; // Store the column
                        }
                        else if (cardsFlipped == 2) // If this was the second card flipped
                        {
                            cardsFlipped = 0; // Reset the cardsFlipped to 0
                            disableUnmatched(); // Remove action listeners from unmatched cards
                            guesses++; // Increment the guesses counter
                            guessesMade.setText("Guesses Made: " + guesses); // Display the guesses
                            String value1 = (String) cardButtons[flippedI][flippedJ].getClientProperty("value"); // Get the value of the first card flipped
                            String value2 = (String) cardButtons[i][j].getClientProperty("value"); // Get the value of the second card flipped
                            if (Objects.equals(value1, value2)) // If the two card values match
                            {
                                matches++; // Increment matches
                                matchesMade.setText("Matches Made: " + matches); // Display matches
                                matchedCards[flippedI][flippedJ] = true; // Adds previously flipped card to matchedCards
                                matchedCards[i][j] = true; // Adds recently flipped card to matchedCards
                                // Pause for 3 seconds
                                Timer timer = new Timer(3000, e12 ->
                                {
                                    flipCardsToBack(); // Flip the cards after 3 seconds
                                    enableUnmatched(); // Add action listeners to unmatched cards
                                    resetButton.setEnabled(true); // Enable the reset button again
                                    gameWon(); // Check if the game is won
                                }); // Add a timer
                                timer.setRepeats(false); // The timer only iterates once
                                timer.start(); // Starts the timer
                            }
                            else // If the two cards don't match
                            {
                                // Pause for 3 seconds
                                Timer timer = new Timer(3000, e13 ->
                                {
                                    flipCardsToBack(); // Flip the cards after 3 seconds
                                    enableUnmatched(); // Add action listeners to unmatched cards
                                    resetButton.setEnabled(true); // Enable the reset button again
                                }); // Add a timer
                                timer.setRepeats(false); // The timer only iterates once
                                timer.start(); // Starts the timer
                            }
                        }
                        break; // Break the loop once the card is found;
                    }
                }
            }
        }
    }
    public static void main(String[] args)
    {
        new cardmatch(); // Creates the JFrame with all of its contents
    }
}